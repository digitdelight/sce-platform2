<h4>Hello Admin,</h4>
You received a message from : {{ $name }}

<p>
    Name: {{ $name }}
</p>

<p>
    Email:  {{ $email }}
</p>

<p>
    Subject:  {{ $subject }}
</p>

<p>
    Message:  {{ $messageDetails }}
</p>