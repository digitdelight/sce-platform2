import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mapv',
  templateUrl: './mapv.component.html',
  styleUrls: ['./mapv.component.css']
})
export class MapvComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
