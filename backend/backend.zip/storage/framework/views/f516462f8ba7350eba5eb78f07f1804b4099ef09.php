<h4>Hello Admin,</h4>
You received a message from : <?php echo e($name); ?>


<p>
    Name: <?php echo e($name); ?>

</p>

<p>
    Email:  <?php echo e($email); ?>

</p>

<p>
    Subject:  <?php echo e($subject); ?>

</p>

<p>
    Message:  <?php echo e($messageDetails); ?>

</p>