import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcontribution',
  templateUrl: './editcontribution.component.html',
  styleUrls: ['./editcontribution.component.css']
})
export class EditcontributionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
