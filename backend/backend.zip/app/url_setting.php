<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class url_setting extends Model
{
    protected $fillable = [
        'url'
    ];
}
